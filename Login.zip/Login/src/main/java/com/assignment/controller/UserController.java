package com.assignment.controller;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.*;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.support.SecurityContextProvider;
import org.springframework.boot.autoconfigure.neo4j.Neo4jProperties.Authentication;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
//import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.servlet.ModelAndView;

import com.assignment.model.UserCredential;
import com.assignment.model.UserInfo;
import com.assignment.repository.UserInfoRepository;
import com.assignment.repository.UserRepository;
import com.assignment.service.UserService;


@CrossOrigin(origins = "*")
@RestController
@RequestMapping("/api")
public class UserController {
	
	@Autowired
	private UserService userService;

	private Map<String, UserInfo>map=new HashMap<String, UserInfo>();
	
	@Autowired
	private UserInfoRepository userInfo;
	
	@Autowired
	private UserRepository userRepository;
	
	public UserController(UserService userService) {
		super();
		this.userService = userService;
	}
	@PostMapping("/saveinfo")
	public String saveData(@RequestBody UserInfo userInfo) {
		return userService.save(userInfo);
	}
	
	@PostMapping("/savecredential")
	public UserCredential saveCredential(@RequestBody UserCredential userCredential) {
		return userService.create(userCredential);
	}
	@PostMapping("/userdetails")
	public ResponseEntity<?> login(@RequestBody UserInfo login){
		UserCredential userCredential=userService.login(login.getEmail(), login.getPassword());
		if (userCredential==null) {
			return ResponseEntity.status(HttpStatus.UNAUTHORIZED)
					.build().badRequest().body("User not exist");
			
		}
		
		if(!userCredential.getPassword().equals(login.getPassword())) {
			return ResponseEntity.badRequest().body("incorrect password");
		}
		UserInfo userInfo=new UserInfo();
		String role=userInfo.getUserType();
		if("U".equals(role)) {
			return ResponseEntity.ok("Succesful login as user");
		}
		else if("A".equals(role)) {
			return ResponseEntity.ok("Successful login as admin");
			
		}
		else {
			return ResponseEntity.badRequest().body("invalid userRole");
		}
	}
	@GetMapping("/ShowExistingUser")
	public ResponseEntity<List<UserInfo>>showExistingUser(String userType){
		if("U".equals(userType)) {
//			String str=SecurityContextHolder.getContext().getAuthentication().getName();
			UserCredential userCredential= userRepository.findByEmail(userType);
			if(userCredential !=null) {
				UserInfo user =userInfo.findById(userCredential.getId());
				if(user!=null) {
					return ResponseEntity.ok(Collections.singletonList(user));
				}
			}
		}
		else if("A".equals(userType)) {
			List<UserInfo> user=userInfo.findAll();
			return ResponseEntity.ok(user);
		}
		return ResponseEntity.badRequest().body(null);
	}
	@PostMapping("/register")
	public ResponseEntity<?> register(@RequestBody UserInfo userInfo){
		UserInfo userInfo2 = userService.register(userInfo);
		if(userInfo2==null) {
			return ResponseEntity.status(HttpStatus.BAD_REQUEST)
					.build();
		}
		return ResponseEntity.ok().body(userInfo2);
	}

	@PostMapping("/authinfo")
	public ResponseEntity<String> UserInfo(@RequestBody UserInfo Log) {
		if(Log.getFirstName()==null || Log.getFirstName().isBlank()) {
			return ResponseEntity.badRequest().body("firstname is required");
		}
		if(Log.getLastName()==null || Log.getLastName().isBlank()) {
			return ResponseEntity.badRequest().body("lastname is required");
		}
	    if(Log.getEmail()==null || Log.getEmail().isBlank()) {
	    	return ResponseEntity.badRequest().body("email is required");
	    }
	    if(Log.getPassword()==null || Log.getPassword().isBlank()) {
	    	return ResponseEntity.badRequest().body("password is required");
	    }
//	    if(Log.getMobileNumber()==null || Log.getMobileNumber().isBlank()) {
//	    	return ResponseEntity.badRequest().body("mobilenumber is required");
//	    }
	    if (Log.getMobileNumber() == 0 ) {
	        return ResponseEntity.badRequest().body("Mobile number is required");
	    
	    }
	    if(Log.getUserType()==null || Log.getUserType().isBlank()) {
	    	return ResponseEntity.badRequest().body("usertype is required");
	    }
	    if(userInfo.existsByEmail(Log.getEmail())){
	    	return ResponseEntity.badRequest().body("email already exists");
	    	
	    }
	    
	    userService.saveData(Log);
	    return ResponseEntity.ok().body("user registered successfully");
	}

	@PostMapping("/registerUser")
	public ResponseEntity<UserInfo> createUser(@RequestBody UserInfo registration){
		if(userService.isEmailAlreadyExists(registration.getEmail())) {
			return new ResponseEntity("email is already exist",HttpStatus.BAD_REQUEST);
			
		}
			userService.registerUser(registration);
			return new ResponseEntity("user registered successfully",HttpStatus.CREATED);
			
		
	}
	@PostMapping("/auth")
	public ResponseEntity<?> loginData(@RequestBody UserInfo register, UserCredential log) throws Exception {
	    if(register.getEmail() == null || register.getEmail().isBlank()) {
	        return ResponseEntity.badRequest().body("email is required");
	    }
	    if(register.getPassword() == null || register.getPassword().isBlank()) {
	        return ResponseEntity.badRequest().body("password is required");
	    }
	    if(userRepository.existsByEmail(log.getEmail())){
	    	return ResponseEntity.badRequest().body("email already exists");
	    	
	    }
	    

	    String email = register.getEmail();
	    String password = register.getPassword();
	    UserInfo registerObj = userService.fetchByEmailPassword(email, password);
	    if(email != null && password != null) {
	    	
	    

	    if(registerObj == null) {
	        throw new Exception("Bad Credentials");
	    }
	   
	    try {
	        // Assuming you don't need to create a new UserCredential object
	         UserCredential login = new UserCredential();
	         login.setEmail(email);
	         login.setPassword(password);

	        // Assuming checkLoginDetails is not needed
	         registerObj = userService.checkLoginDetails(register.getEmail(), register.getPassword());

	        // Assuming create method saves the login details in the database
	        userService.create(login);

	        return ResponseEntity.ok("Login successful");
	    } catch(Exception e) {
	        e.printStackTrace();
	        if(userService.isEmailAlreadyExists(register.getEmail())) {
				return new ResponseEntity("email is already exist",HttpStatus.BAD_REQUEST);
				
			}
	        return ResponseEntity.status(403).body("Invalid login details");
	       
	    }
	    
	   
	   
	}
	   

	 return new ResponseEntity("wrong details",HttpStatus.OK);

	}
	

//	@PostMapping("/auth")
//	public ResponseEntity<?> loginData(@RequestBody UserInfo register) {
//	    if (register.getEmail() == null || register.getEmail().isBlank()) {
//	        return ResponseEntity.badRequest().body("email is required");
//	    }
//
//	    if (register.getPassword() == null || register.getPassword().isBlank()) {
//	        return ResponseEntity.badRequest().body("password is required");
//	    }
//
//	    String response = "";
//	    int status = 403;
//	    String email = register.getEmail();
//        String password = register.getPassword();
//	    UserCredential login = new UserCredential();
//        login.setEmail(email);
//        login.setPassword(password);
//
//	    try {
//	        
//
//	        // Check login credentials
//	        UserInfo registerObj = userService.fetchByEmailPassword(email, password);
//	       
//
//	        if (registerObj != null) {
//	            response = "login successful";
//	            userService.create(login);
//	            status = 200;
//	        } else {
//	            throw new Exception("Bad Credentials");
//	        }
//
//	    } catch (Exception e) {
//	        // Handle specific exceptions here
//	        response = "invalid login details";
//	    }
//
//	    return ResponseEntity.status(status).body(response);
//	}



	@DeleteMapping("/delete")
	public void deleteId(int id) {
		userService.delete(id);
	}
	@PostMapping("/upload-customers-data")
    public ResponseEntity<?> uploadCustomersData(@RequestParam("file")MultipartFile file){
        this.userService.saveCustomersToDatabase(file);
        return ResponseEntity
                .ok(Map.of("Message" , " Customers data uploaded and saved to database successfully"));
        
    }

	

    @GetMapping
    public ResponseEntity<List<UserInfo>> getCustomers(){
//        return new ResponseEntity<>(customerService.getCustomers(), HttpStatus.FOUND);
    	List<UserInfo> list=userService.getCustomers();
    	return new ResponseEntity<List<UserInfo>>(list,HttpStatus.OK);
    }
}
