package com.assignment.service;

import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Objects;

import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.springframework.web.multipart.MultipartFile;

import com.assignment.model.UserInfo;


public class ExcelUploadService {
	public static boolean isValidExcelFile(MultipartFile file){
        return Objects.equals(file.getContentType(), "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet" );
    }
	public static List<UserInfo> getCustomersDataFromExcel(InputStream inputStream) {
	    List<UserInfo> customers = new ArrayList<>();
	    try {
	        XSSFWorkbook workbook = new XSSFWorkbook(inputStream);
	        XSSFSheet sheet = workbook.getSheet("customers");

	        if (sheet == null) {
	            throw new IllegalArgumentException("Sheet with name 'customers' not found in the Excel workbook");
	        }

	        int rowIndex = 0;
	        for (Row row : sheet) {
	            if (rowIndex == 0) {
	                rowIndex++;
	                continue;
	            }
	            Iterator<Cell> cellIterator = row.iterator();
	            int cellIndex = 0;
	            UserInfo userinfo = new UserInfo();
	            while (cellIterator.hasNext()) {
	                Cell cell = cellIterator.next();
	                switch (cellIndex) {
	                    case 0 -> userinfo.setFirstName(cell.getStringCellValue());
	                    case 1 -> userinfo.setLastName(cell.getStringCellValue());
	                    case 2 -> userinfo.setEmail(cell.getStringCellValue());
	                    case 3 -> userinfo.setMobileNumber((long) cell.getNumericCellValue());
	                    case 4 -> userinfo.setUserType(cell.getStringCellValue());
	                    case 5 -> userinfo.setPassword(cell.getStringCellValue());
	                    default -> {
	                    }
	                }
	                cellIndex++;
	            }
	            customers.add(userinfo);
	        }
	    } catch (IOException e) {
	        e.printStackTrace();
	    }
	    return customers;
	}



}
