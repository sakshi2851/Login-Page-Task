package com.assignment.service;

import java.io.IOException;
import java.util.Iterator;
import java.util.List;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;


import com.assignment.model.UserCredential;
import com.assignment.model.UserInfo;
import com.assignment.repository.UserInfoRepository;
import com.assignment.repository.UserRepository;



@Service
public class UserService {
	
	@Autowired
	private UserRepository userRepository; 
	
	@Autowired
	private  UserInfoRepository userInfoRepository;
	
	public UserService(UserRepository UserRepository,UserInfoRepository userInfoRepository) {
		this.userRepository=userRepository;
		this.userInfoRepository=userInfoRepository;
	
	}
	public List<UserInfo>getAll(){
		return userInfoRepository.findAll();
	}
	public UserCredential login(String email,String password) {
		UserCredential usercredential=userRepository.findByEmail(email);
		if(usercredential==null || !usercredential.getPassword().equals(password)) {
			return null;
		}
		return usercredential;
	}
	public UserInfo register(UserInfo userInfo) {
		UserCredential usercredential= new UserCredential();
		usercredential.setEmail(usercredential.getEmail());
		usercredential.setPassword(usercredential.getPassword());
		userRepository.save(usercredential);
		userInfo.setUserType("U");
		userInfoRepository.save(userInfo);
		return userInfo;
	}
	public String save(UserInfo userInfo) {
		List users=userInfoRepository.findAll();
		boolean isUserExists=false;
		for (Iterator iterator = users.iterator(); iterator.hasNext();) {
			UserInfo user = (UserInfo) iterator.next();
			if(user.getEmail().equals(userInfo.getEmail())) {
				isUserExists=true;
			}
			
		};
		if(isUserExists) {
			return "user already exists";
		}
		userInfoRepository.save(userInfo);
		return "user details saved successfully";
	}
	public UserCredential create(UserCredential userCredential) {
		return userRepository.save(userCredential);
	}
	public boolean isEmailAlreadyExists(String email) {
		return userInfoRepository.existsByEmail(email);
	}
	public void registerUser(UserInfo userInfo) {
		UserCredential login=new UserCredential();
		login.setEmail(userInfo.getEmail());
		userRepository.save(login);
	}
	public void delete(int id) {
		userInfoRepository.deleteById(id);
	}

	public UserInfo fetchByEmailPassword(String email, String password) {
		return userInfoRepository.findByEmailAndPassword(email, password);
	}
	public UserInfo saveData(UserInfo user) {
		return userInfoRepository.save(user);
	}
	

	public UserInfo checkLoginDetails(String email,String password)throws Exception{
		if(userInfoRepository.findAll().parallelStream().noneMatch(p->p.getEmail().equals(email))) {
			System.out.println("loginRepository"+email);
			throw new Exception("email not found");
			

	}
		if(userInfoRepository.findAll().parallelStream().noneMatch(p->p.getPassword().equals(password))) {
			System.out.println("loginRepository"+password);
			throw new Exception("password not found");
		}
		if(userInfoRepository.findAll().parallelStream().filter(p->p.getEmail().equals(email)).collect(Collectors.toList()).get(0)!=null) {
			System.out.println("wrongRepository"+email);
		}
		
		System.out.println("loginRepository"+password);
			return userInfoRepository.findAll().parallelStream().filter(p->p.getPassword().equals(password)).collect(Collectors.toList()).get(0);
				
			}
			
		
	public boolean matchesPassword(String password,String encodedPassword) {
		return password.equals(encodedPassword);
	}
	public void saveCustomersToDatabase(MultipartFile file){
        if(ExcelUploadService.isValidExcelFile(file)){
            try {
                List<UserInfo> customers = ExcelUploadService.getCustomersDataFromExcel(file.getInputStream());
                this.userInfoRepository.saveAll(customers);
            } catch (IOException e) {
                throw new IllegalArgumentException("The file is not a valid excel file");
            }
        }
    }
	 public List<UserInfo> getCustomers(){
	        return userInfoRepository.findAll();
	    }

}





	
	

